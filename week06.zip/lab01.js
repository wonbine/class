		function f1(x){
			x.style.background='indigo';
			x.style.width = "300px";
			x.style.height = "300px";
		}
		function f2(x){
			x.style.background='gray';
			x.style.width='500px'
			x.style.height='500px'
			}
			function over(x1){
				x1.src="../week06/myimage.jpg";}
			function out(x1){
				x1.src="../week06/myimage2.jpg";
			}